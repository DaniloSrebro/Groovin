﻿<?php
session_start(); // Start session at the beginning

if (!isset($_SESSION['user_id'])) {
  // Redirect to login page if user is not logged in
  header("Location: ./forms/Login.php");
  exit();
}
// Database connection
$servername = "localhost";
$username = "root";
$password = "Sinke008";
$dbname = "rezervacije";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Load user info if logged in
$user = null; // Define $user variable to avoid undefined variable notice
if (isset($_SESSION["user_id"])) {
    $mysqli = require __DIR__ . "/forms/database.php";
    $sql = "SELECT * FROM user WHERE id = {$_SESSION["user_id"]}";
    $result = $mysqli->query($sql);
    $user = $result->fetch_assoc();
}

$isLoggedIn = isset($_SESSION["user_id"]);

// Close the MySQL connection
$conn->close();

$servername = "localhost";
$username = "root";
$password = "Sinke008";
$dbname = "login_db";

$mysqli = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$query = "SELECT bodovi AS rankbodovi FROM user WHERE id = {$_SESSION["user_id"]}";
$result = $mysqli->query($query);

if ($result) {
    $row = $result->fetch_assoc();
    $bodovi = $row['rankbodovi'];
    if($bodovi < 3){
      $message = "CloudBurst";
    }
    elseif ($bodovi < 5) {
      $message = "Storm";
    }
    elseif ($bodovi < 8) {
      $message = "Tornado";
    }
    elseif ($bodovi < 10) {
      $message = "Hurricane";
    }
    elseif ($bodovi < 15) {
        $message = "Monsoon";
    } elseif ($bodovi >= 10 && $bodovi <= 20) {
        $message = "Typhoon";
    } else {
        $message = "Cyclone";
    }
} else {
    echo "Query failed: " . $mysqli->error;
}

$mysqli->close();
?>

<?php
    $userime = htmlspecialchars($user["username"]);
        $email = htmlspecialchars($user["email"]);
?>




<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Profil</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logopartym.png" rel="icon">
  <link href="assets/img/logopartym.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anta&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <link rel="stylesheet" href="./assets/css/styleprofil.css">

<link rel="stylesheet" href="./assets/css/demo.css">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;600&display=swap" rel="stylesheet">



  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="./assets/css/profil.css" rel="stylesheet">

  

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $('.status').each(function(){
        var statusText = $(this).text();
        switch(statusText) {
            case 'approved':
                $(this).css('background-color', 'green');
                break;
            case 'rejected':
                $(this).css('background-color', 'red');
                break;
            case 'pending':
                $(this).css('background-color', '#F87515');
                break;
            default:
                // Do nothing
        }
    });
});
</script>

<style>
  .account-settings .user-profile {
    margin: 0 0 1rem 0;
    padding-bottom: 1rem;
    text-align: center;
}
.account-settings .user-profile .user-avatar {
    margin: 0 0 1rem 0;
}
.account-settings .user-profile .user-avatar img {
    width: 90px;
    height: 90px;
    -webkit-border-radius: 100px;
    -moz-border-radius: 100px;
    border-radius: 100px;
}
.account-settings .user-profile h5.user-name {
    margin: 0 0 0.5rem 0;
}
.account-settings .user-profile h6.user-email {
    margin: 0;
    font-size: 0.8rem;
    font-weight: 400;
    color: #9fa8b9;
}
.account-settings .about {
    margin: 2rem 0 0 0;
    text-align: center;
}
.account-settings .about h5 {
    margin: 0 0 15px 0;
    color: #007ae1;
}
.account-settings .about p {
    font-size: 0.825rem;
}
.form-control {
    border: 1px solid #cfd1d8;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    font-size: .825rem;
    background: #ffffff;
    color: #2e323c;
}

.card {
    background: #ffffff;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    border-radius: 5px;
    border: 0;
    margin-bottom: 1rem;
}
.reservation {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    padding: 20px;
    margin: 20px 0;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.reservation p {
    color: #333;
    line-height: 1.6;
}

.reservation .status {
    font-weight: bold;
    color: white; /* Green for available or confirmed statuses, you can change this based on the status */
}
</style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      
      <h1 class="logo"><a href="index.html">Party M</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      

<nav id="navbar" class="navbar">
        <ul>
          
          <li><a class="nav-link scrollto" href="./index.php">Početna</a></li>
         
          
          
        
          
         
          <li class="dropdown"><a href="#"><span>Lokali</span> <i class="bi bi-chevron-down"></i></a>
            <ul>

              
              <li><a href="./restoranikafici.php">Restorani i Kafići</a></li>
              
              
            </ul>
            <li><a class="nav-link active" href="./profil.php">Profil</a></li>
          </li>
          <li><a class="nav-link scrollto" href="./index.php#contact">Kontakt</a></li>
          <?php if($isLoggedIn): ?>
            <li><a class="getstartedout scrollto" href="./forms/logout.php">Logout</a></li>
          <?php else: ?>
            <li><a class="getstarted scrollto" href="./forms/Login.php">Login</a></li>
        <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center" style="color: white;">
          <h2><button class="button1" data-text="Awesome">
    <span class="actual-text">&nbsp;Profil&nbsp;</span>
    <span aria-hidden="true" class="hover-text">&nbsp;Profil&nbsp;</span>
</button></h2>
          <ol>
            <li><a href="index.php">Party M</a></li>
            <li>Profil</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

  
      
    <div class="container">
<div class="row gutters">
<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
		<div class="account-settings">
			<div class="user-profile">
				<div class="user-avatar">
					<img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Maxwell Admin">
				</div>
				<h5 class="user-name"><?php echo $userime; ?></h5>
				<h6 class="user-email"><?php echo $email; ?></h6>
			</div>
			<div class="about">
				<h5>Rank: <?php echo $message; ?></h5>
				<p><?php echo $bodovi; ?></p>
			</div>
		</div>
	</div>
</div>
</div>
<div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
<div class="card h-100">
	<div class="card-body">
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<h6 class="mb-2 text-primary">Trenutne Rezervacije</h6>
			</div>


			<div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
        <?php
// Database configurations
$user_db_host = "localhost";
$user_db_username = "root";
$user_db_password = "Sinke008";
$user_db_name = "login_db"; // Database containing the users table

$reservations_db_host = "localhost";
$reservations_db_username = "root";
$reservations_db_password = "Sinke008";
$reservations_db_name = "rezervacije"; // Database containing the reservations table

// Create connection to users database
$user_conn = mysqli_connect($user_db_host, $user_db_username, $user_db_password, $user_db_name);

// Check connection to users database
if (!$user_conn) {
    die("User database connection failed: " . mysqli_connect_error());
}

// Create connection to reservations database
$reservations_conn = mysqli_connect($reservations_db_host, $reservations_db_username, $reservations_db_password, $reservations_db_name);

// Check connection to reservations database
if (!$reservations_conn) {
    die("Reservations database connection failed: " . mysqli_connect_error());
}

// Start session to access session variables


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: ./forms/Login.php");
    exit();
}

// Get the user's ID from the session
$user_id = $_SESSION['user_id'];

// Query to retrieve reservations for the user
// $sql_cubalibre = "SELECT * FROM $reservations_db_name.cubalibre WHERE id = $user_id";
$sql_tocionica = "SELECT * FROM $reservations_db_name.tocionica WHERE id = $user_id";

// Execute the queries
// $result_cubalibre = mysqli_query($reservations_conn, $sql_cubalibre);
$result_tocionica = mysqli_query($reservations_conn, $sql_tocionica);

// Check if there are any reservations in cubalibre
// if (mysqli_num_rows($result_cubalibre) > 0) {
//     // Display reservations
//     while ($row = mysqli_fetch_assoc($result_cubalibre)) {
//         displayReservation($row);
//     }
// }

// Check if there are any reservations in tocionica
if (mysqli_num_rows($result_tocionica) > 0) {
  
    while ($row = mysqli_fetch_assoc($result_tocionica)) {
        displayReservation($row);
    }
}
if (mysqli_num_rows($result_tocionica) === 0) {
  echo "Trunutno nemate rezervacija.";
  while ($row = mysqli_fetch_assoc($result_tocionica)) {
      displayReservation($row);
  }
}

// Function to display reservation and handle deletion
function displayReservation($row) {
    echo "<div class='reservation'>";
    echo "<p><strong>Mesto:</strong>" . $row['mesto'] . "</span></p>";
    echo "<p><strong>Za dan:</strong> " . $row['zadatum'] . "</p>";
    echo "<p><strong>Vreme dolaska:</strong> " . $row['vremedolaska'] . "</p>";
    echo "<p><strong>Rezervacija napravljena:</strong> " . $row['vremerez'] . "</p>";
    echo "<p><strong>Status rezervacije:</strong> <span class='status'>" . $row['reservationstatus'] . "</span></p>";
    
    // Add a form to handle deletion
    
    
    if ($row['reservationstatus'] == 'approved') {
      echo "<p>Vidimo se tamo!</p>";
  
      // Display the HTML form for rating
      echo '<form method="post" action="' . $row['mesto'] . 'process_rating.php">
                <div class="rating" style="font-style: normal;">
                    <input value="5" name="rating" id="star5" type="radio">
                    <label for="star5"></label>
                    <input value="4" name="rating" id="star4" type="radio">
                    <label for="star4"></label>
                    <input value="3" name="rating" id="star3" type="radio">
                    <label for="star3"></label>
                    <input value="2" name="rating" id="star2" type="radio">
                    <label for="star2"></label>
                    <input value="1" name="rating" id="star1" type="radio">
                    <label for="star1"></label>
                </div>
                <button type="submit" class="ocenidugme"><span>Oceni</span></button>
            </form>';
            
  
    } elseif ($row['reservationstatus'] == 'rejected') {
        echo "<p>Rezervacija nije odobrena... <br> Obrišite i pokušajte ponovo!</p>";
    } elseif ($row['reservationstatus'] == 'pending') {
        echo "<p>Rezervacija u najkracem roku bi trebala biti potvrdjena</p>";
    }
    echo "<form method='POST'>";
    echo "<input type='hidden' name='user_id' value='" . $_SESSION['user_id'] . "'>";
    echo "<input type='hidden' name='mesto' value='" . $row['mesto'] . "'>";
    echo "<button class='button-45' type='submit' name='delete_reservation' onclick='reloadWithTimeout()''>Obrisi Rez.</button>";
    echo "</form>";


    echo "</div>";
    echo "<hr>";
}

// Handle reservation deletion
if(isset($_POST['delete_reservation'])) {
    $user_id = $_POST['user_id'];
    $mesto = $_POST['mesto'];

    // Construct your SQL query with user ID and reservation details
    $sql = "DELETE FROM $mesto WHERE id = '$user_id' AND mesto = '$mesto'";

    // Execute the query
    $result = mysqli_query($reservations_conn, $sql);

    // Check if the query was successful
    if ($result) {
        echo "Reservation deleted successfully.";
    } else {
        echo "Error deleting reservation: " . mysqli_error($reservations_conn);
    }
}

// Close the connections
mysqli_close($user_conn);
mysqli_close($reservations_conn);
?>
					


				</div>
			</div>
			
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <br>
        <br>
				<h6 class="mt-3 mb-2 text-primary">Istorija</h6>
			</div>
			<div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="form-group">
        <?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "Sinke008";
$dbname = "rezervacije";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// User ID


// SQL query to fetch data from the tocionicaistorija table for the given user ID
$sql = "SELECT * FROM tocionicaistorija WHERE id = $user_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Begin by adding a style tag for general table styling
  echo "<style>
      table {
          width: 100%;
          border-collapse: collapse;
          margin: 25px 0;
          font-size: 0.9em;
          font-family: sans-serif;
          min-width: 400px;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
      }
      th, td {
          padding: 12px 15px;
          text-align: left;
          border-bottom: 1px solid #dddddd;
      }
      th {
          background-color: #009879;
          color: #ffffff;
          text-transform: uppercase;
      }
      tr:nth-of-type(even) {
          background-color: #f3f3f3;
      }
      tr:last-of-type {
          border-bottom: 2px solid #009879;
      }
      @media screen and (max-width: 800px) {
        table {
          width: 60%;
            font-size: 0.8rem;
            margin: 10 0;
            min-width: 200px;
        }
    }
      </style>";

  // Output data of each row in a table format
  echo "<table border='1'>";
  echo "<tr>
  <th>Mesto:</th>
  <th>Datum:</th>
  <th>Vreme Dolaska:</th>
  <th>Vrsta Rezervacije</th>
  </tr>";
  while($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td>" . $row["mesto"] . "</td>";
      echo "<td>" . $row["zadatum"] . "</td>";
      echo "<td>" . $row["vremedolaska"] . "</td>";
      echo "<td>" . $row["vrstarez"] . "</td>";
      echo "</tr>";
  }
  echo "</table>";
} else {
  echo "Nemate potvrdjenih rezervacija..";
}
$conn->close();
?>
				</div>
			</div>
			
		<div class="row gutters">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<div class="text-right">
         
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>





<!-- function displayReservation($row) {   //ZA SVAKI SLUCAJ posto menjam sad  
    echo "<div class='reservation'>";
    echo "<h4><strong>Mesto:</strong> <span class='status'>" . $row['mesto'] . "</span></h4>";
    echo "<p><strong>Ime:</strong> <span class='status'>" . $row['ime'] . "</span></p>";
    echo "<p><strong>Broj ljudi:</strong> " . $row['brojljudi'] . "</p>";
    echo "<p><strong>Broj stola:</strong> " . $row['brojstola'] . "</p>";
    echo "<p><strong>Za dan:</strong> " . $row['zadatum'] . "</p>";
    echo "<p><strong>Vreme dolaska:</strong> " . $row['vremedolaska'] . "</p>";
    echo "<p><strong>Vrsta Rezervacije:</strong> " . $row['vrstarez'] . "</p>";
    echo "<p><strong>Rezervacija napravljena:</strong> " . $row['vremerez'] . "</p>";
    echo "<p><strong>Status rezervacije:</strong> <span class='status'>" . $row['reservationstatus'] . "</span></p>"; -->




     


      



















      




    
</main>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <h3>Party M <img src="./assets/img/logopartym.png" alt="" style="width:70px; height:70px;"></h3>
              
              <p>
                <strong>Email:</strong> info@partym.rs<br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 offset-lg-6 col-md-6 footer-links">
            <h4>Nasi Servisi</h4>
            <ul>
              
              <li><i class="bx bx-chevron-right"></i> <a href="./restoranikafici.php">Restorani/Kafici</a></li>
              
              
            </ul>
            <br>
            <h4>Partneri:</h4>
            <ul>
              
              <li><i class="bx bx-chevron-right"></i> <a href="./tocionica/tocionica.php">Točionica</a></li>
              
              
            </ul>
            
          </div>

          

        </div>
      </div>
    </div>
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Party M</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        Designed by Zaun
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
    // JavaScript function to reload the page every 30 seconds
    setTimeout(function() {
        location.reload();
    }, 30000); // 30 seconds (30,000 milliseconds)
</script>


</body>

</html>