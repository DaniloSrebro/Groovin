<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <!-- Add any CSS styling here if needed -->
    <style>
        body {
            overflow-x: hidden; 
            background: url(./assets/img/infopozadina.png);
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            font-family: "PT Sans", sans-serif;
            font-style: italic;
            height: 100vh; /* Ensure full viewport height */
            margin: 0; /* Remove default margin */
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: center;
             
        }
        .message-container {
            background-color: rgba(255, 255, 255, 0.3); /* Transparent white background */
            padding: 20px;
            border-radius: 10px;
            text-align: center; /* Center text horizontally */
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1); /* Optional: add box shadow */
            backdrop-filter: blur(25px);
        }
        .thank-you-message {
            height: auto;
            text-align: center;
            
            font-size: 30px;
            color: black;
           
        }
        .error-message {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
<?php
session_start();

// Establish database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "Sinke008"; // Replace with your MySQL password
$database = "ocene"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$htmlPageUrl = "./profil.php";
// Check if form is submitted and data is valid
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['rating']) && isset($_SESSION['user_id'])) {
    $rating = $_POST['rating'];
    $user_id = $_SESSION['user_id'];

    // Prepare and bind insert statement
    $check_stmt = $conn->prepare("SELECT COUNT(*) AS count FROM tocionicaocene WHERE id = ?");
    $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];

    if ($count > 0) {
        // User has already submitted a rating, display a user-friendly message
        echo "<div class='message-container'><div class='thank-you-message'>Dozvoljeno je samo jednom oceniti klub, <br> vratite se na <a href='$htmlPageUrl'>profil</div></div>";
        
    } else {
        // Prepare and bind insert statement
        $stmt = $conn->prepare("INSERT INTO tocionicaocene (id, rating) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $rating);

        // Execute insert statement
        if ($stmt->execute() === TRUE) {
            echo "<div class='message-container'><div class='thank-you-message'>Hvala vam što koristite Party M, <br> povratak na <a href='$htmlPageUrl'>profil</div></div>";
        } else {
            echo "<div class='error-message'>Error: " . $stmt->error . "</div>";
        }

        $stmt->close();
    }

    $check_stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>
</body>
</html>