<?php
// dbconfig.php
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = "Sinke008"; // Replace with your MySQL password
$database = "rezervacije"; // Replace with your database name
