<?php
// dbconfig.php
$servername = "localhost";
$username = "root";
$password = "Sinke008"; 
$database1 = "login_db"; 
$database2 = "rezervacije"; 
