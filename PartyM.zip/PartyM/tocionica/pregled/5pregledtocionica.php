<?php
include 'dbconnect.php';

$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$mysqli = new mysqli($servername, $username, $password, $database);

$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = CURDATE() AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable = $row['row_count'];


$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = DATE_ADD(CURDATE(), INTERVAL 1 DAY) AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable1 = $row['row_count'];

$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = DATE_ADD(CURDATE(), INTERVAL 2 DAY) AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable2 = $row['row_count'];

$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = DATE_ADD(CURDATE(), INTERVAL 3 DAY) AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable3 = $row['row_count'];

$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = DATE_ADD(CURDATE(), INTERVAL 4 DAY) AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable4 = $row['row_count'];

$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = DATE_ADD(CURDATE(), INTERVAL 5 DAY) AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable5 = $row['row_count'];

$query = "SELECT COUNT(*) AS row_count FROM tocionica WHERE zadatum = DATE_ADD(CURDATE(), INTERVAL 6 DAY) AND reservationstatus='approved'";
$result = $mysqli->query($query);
$row = $result->fetch_assoc();
$row_count_variable6 = $row['row_count'];

$mysqli->close();

$conn->close();

session_start();

if (!isset($_SESSION['manager_id'])) {
  // Redirect to login page if user is not logged in
  header("Location: ../../formsmenadzer/Login.php");
  exit();
}

if (isset($_SESSION["manager_id"])) {
    
    $mysqli = require __DIR__ . "../../../formsmenadzer/database.php";
    
    $sql = "SELECT * FROM manager
            WHERE id = {$_SESSION["manager_id"]}";
            
    $result = $mysqli->query($sql);
    
    $manager = $result->fetch_assoc();
}

$isLoggedIn = isset($_SESSION["manager_id"]);

// Load manager info if logged in
if ($isLoggedIn) {
    $mysqli = require __DIR__ . "../../../formsmenadzer/database.php";
    $manager_id = $_SESSION["manager_id"];
    $sql = "SELECT * FROM manager WHERE id = $manager_id";
    $result = $mysqli->query($sql);

    if ($result && $result->num_rows > 0) {
        $manager = $result->fetch_assoc();
        
        // Check if email is tocionica@gmail.com
        if ($manager['email'] === 'tocionica@menadzer.com') {
            ?>
            


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Party M - Menadžer</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../../assets/img/logopartym.png" rel="icon">
  <link href="../../assets/img/logopartym.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anta&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../../assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="../../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../../assets/" rel="stylesheet">
  <link href="../../assets//vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../../assets//vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../../assets/css/style.css" rel="stylesheet">
  <link href="../../assets/css/tocionicapregled.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      
      <h1 class="logo" style="color:white">Party M Menadžer</h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

    

      <nav id="navbar" class="navbar">
        <ul>
          
        <li><a class="nav-link active" href="#">Pregled</a></li> 
        <li  id="rez"><a class="nav-link" href="../rezervacije/tocionicamenadzer.php">Rezervacije</a></li> 
        
        <li class="dropdown"><a href="#"><span>Istorija</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
            <li><a class="nav-link" href="../istorija/potvrdjenerez.php">Potvrđene rezervacije</a></li>
           <li><a class="nav-link" href="../istorija/nepotvrdjenerez.php">Nepotvrđene rezervacije</a></li>
           <li><a class="nav-link" href="../istorija/odbijenerez.php" style="background-color:red">Odbijene Rezervacije</a></li>
              
            </ul>
          </li>
          
          
          
          <?php if($isLoggedIn): ?>
            <li><a class="getstartedout scrollto" href="../../formsmenadzer/logout.php">Logout</a></li>
          <?php else: ?>
            <li><a class="getstarted scrollto" href="../../formsmenadzer/Login.php">Login</a></li>
        <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      

    </div>
  </header><!-- End Header -->

  <main id="main">

  
    <br>
  <br>
  <br>
    <div class="container2">
      
    <a href="./pregledtocionica.php"><button class="button1" id="todayBtn">Today</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable; ?></p></a>
    <a href="./1pregledtocionica.php"><button class="button1" id="tomorrowBtn">Tomorrow</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable1; ?></p></a>
    <a href="./2pregledtocionica.php"><button class="button1" id="dayAfterTomorrowBtn">Day after Tomorrow</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable2; ?></p></a>
    <a href="./3pregledtocionica.php"><button class="button1" id="day3Btn">In 3 Days</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable3; ?></p></a>
    <a href="./4pregledtocionica.php"><button class="button1" id="day4Btn">In 4 Days</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable4; ?></p></a>
    <a href="#"><button class="button1" id="day5Btn" style="background-color: #ffc506;">In 5 Days</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable5; ?></p></a>
    <a href="./6pregledtocionica.php"><button class="button1" id="day6Btn">In 6 Days</button><br><p style="color:white; margin-left: 48%;"><?php echo $row_count_variable6; ?></p></a>
    </div>






<div id="hidden" style="display: none"></div>

    <h2 class="nadolazece">Nadolazeće rezervacije:</h2>

<?php
// Database connection details
include 'dbconnect.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);


// SQL query to retrieve reservations
$sql_select = "SELECT id, Ime, brojtelefona, brojstola, vrstarez, brojljudi, vremedolaska FROM tocionica WHERE reservationstatus='approved' AND zadatum = DATE_ADD(CURDATE(), INTERVAL 5 DAY) ORDER BY vremedolaska asc";

// Execute query
$result = $conn->query($sql_select);



// Check if there are results
if ($result->num_rows > 0) {
echo "<div class='reservation-container'>";
// Output data as a table
echo "<table class='reservation-table'>";
echo "<tr>
      <th><i class='bi bi-gear'></i></th>
      <th>Ime</th>
      <th>Broj ljudi</th>
      <th>Vreme Dolaska</th>
      <th>Broj stola</th>
      <th>Vrsta Rez.</th>
      <th>Broj telefona</th>
    </tr>";

while ($row = $result->fetch_assoc()) {
  echo "<tr>";
  echo "<td class='column-ime'>
  <div class='containersmesti'>
    <button onclick='toggleForm(this)' class='icon-button'><i class='bi bi-three-dots-vertical'></i></button>
    <div class='popuppromeni' style='display: none;'>
        <form method='post' action='../akcije/podesi/5podesi.php'>
            <input type='hidden' name='reservation_id' value='" . $row["id"] . "'>
            <label for='inputField'>Novi Sto:</label><br>
            <input type='number' id='inputField' placeholder='Broj stola../..' class='promenistoinput' name='inputField' required><br>
            <button type='submit' class='promenidugme'>Promeni</button>
        </form>
        <br>
        <p>ili</p>
        <form method='post' action='../akcije/vrati/5vrati.php'>
            <input type='hidden' name='reservation_id' value='" . $row["id"] . "'>
            <button type='submit' class='vratidugme'>Pending</button>
        </form>
    </div>
</div>
  </td>";
  echo "<td class='column-ime'>" . $row["Ime"] . "</td>";
  echo "<td class='column-broj-ljudi' style='font-weight: bold;font-size: 20px;'>" . $row["brojljudi"] . "</td>";
  echo "<td class='column-vreme-dolaska'>" . $row['vremedolaska'] . "</td>";
  echo "<td class='column-broj-stola'>" . $row["brojstola"] . "</td>";
  echo "<td class='column-prezime'>" . $row['vrstarez'] . "</td>";
  echo "<td class='column-broj-telefona'>" . $row["brojtelefona"] . "</td>";
  

  // Dodati dugme za rezervacija stigla

         

  echo "</tr>";
}
echo "</table>";
echo "</div>"; // Close reservation-container div

} else {
echo "<p class='no-reservation' style='color:white;'>Nema trenuthih rezervacija.</p>";
}

// Close connection
$conn->close();

?>













<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


    








  
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Party M</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        Designed by Zaun
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../../assets/"></script>
  <script src="../../assets//vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../../assets//vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../../assets//vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../../assets//vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../assets//vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../../assets//js/main.js"></script>




<script>
function checkForNewReservation1() {
    <?php
    // Connect to your database
    include 'dbconnect.php';

    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if there's a row with tomorrow's date and reservation status pending
    
    $sql = "SELECT * FROM tocionica WHERE reservationstatus = 'pending' AND zadatum BETWEEN CURDATE() AND CURDATE() + INTERVAL 6 DAY;";
    $result = $conn->query($sql);

    // Output JavaScript code based on the query result
    echo "if (" . $result->num_rows . " > 0) {";
      echo "  document.getElementById('rez').classList.add('shine');"; // Change '.glowing' to '.shine'
      echo "} else {";
      echo "  document.getElementById('rez').classList.remove('shine');"; // Change '.glowing' to '.shine'
      echo "}";

    $conn->close();
    ?>
}

// Check for updates every 5 seconds
setInterval(checkForNewReservation1, 1000);
</script>

<script>
  // Function to get date string with a specific offset
  function getDateString(offset) {
    const today = new Date();
    const targetDate = new Date(today);
    targetDate.setDate(today.getDate() + offset);
    return targetDate.toDateString();
  }

  // Function to update button text
  function updateButtonText() {
    document.getElementById('todayBtn').innerText = getDateString(0);
    document.getElementById('tomorrowBtn').innerText = getDateString(1);
    document.getElementById('dayAfterTomorrowBtn').innerText = getDateString(2);
    document.getElementById('day3Btn').innerText = getDateString(3);
    document.getElementById('day4Btn').innerText = getDateString(4);
    document.getElementById('day5Btn').innerText = getDateString(5);
    document.getElementById('day6Btn').innerText = getDateString(6);
  }

  // Update button text on page load
  updateButtonText();
</script>

<script>
// Function to reload the page every 60 seconds
function reloadPage() {
    location.reload();
}

// Reload the page every 60 seconds
setInterval(reloadPage, 60000); // 60,000 milliseconds = 60 seconds
</script>


<script>
  function openPopup() {
    document.getElementById('popup').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closePopup() {
    document.getElementById('popup').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}
</script>

<script>
function closePopupPromeni() {
    document.getElementsByClassName('popuppromeni').style.display = 'none';
}
</script>


<script>
  function toggleForm(button) {
    var formContainer = button.parentElement.querySelector('.popuppromeni');
    formContainer.style.display = (formContainer.style.display === 'block') ? 'none' : 'block';
}

</script>

<script>
  var inputField = document.getElementById('inputField');

// Set the minimum and maximum values
inputField.setAttribute('min', '1');
inputField.setAttribute('max', '40');
</script>







</body>

</html>

<?php
        } else {
          ?>
           
            <script>
                alert("You are not authorized to access this page.");
            </script>
            <?php
        }
    } else {
        // Handle case where no manager found with the given ID
        echo "Manager not found.";
    }
}



?>