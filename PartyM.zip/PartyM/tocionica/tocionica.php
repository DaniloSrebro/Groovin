<?php
// Connect to your database
include 'dbconnect.php';

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the sum of brojljudi
$sql = "SELECT SUM(brojljudi) AS total FROM tocionica WHERE reservationstatus='approved'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $total_brojljudi = $row["total"];
    }
} else {
    $total_brojljudi = 0;
}

$conn->close();

session_start();

if (isset($_SESSION["user_id"])) {
    
    $mysqli = require __DIR__ . "../../forms/database.php";
    
    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";
            
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();
}

$isLoggedIn = isset($_SESSION["user_id"]);

// Load user info if logged in
$user_email = "";
if ($isLoggedIn) {
    $mysqli = require __DIR__ . "../../forms/database.php";
    $sql = "SELECT * FROM user WHERE id = {$_SESSION["user_id"]}";
    $result = $mysqli->query($sql);
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (isset($user['email'])) {
            $user_email = $user['email'];
        }
    }
}




?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Party M - Točionica</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/logopartym.png" rel="icon">
  <link href="../assets/img/logopartym.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
  

 
  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/" rel="stylesheet">
  <link href="../assets//vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets//vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">
  <link href="../assets/css/restoran.css" rel="stylesheet">
 

</head>

<body>
<div id="preloader">
  
  </div>
 

  <header id="header" class="fixed-top d-flex align-items-center" style="font-style:italic">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="../index.php">Party M</a></h1>
      

      <nav id="navbar" class="navbar">
        <ul>
          
          <li><a class="nav-link scrollto" href="../index.php">Početna</a></li>
         
          
          
        
          
         
          <li class="dropdown  active"><a href="#"><span>Lokali</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              
              
              <li><a href="../restoranikafici.php">Restorani i Kafici</a></li>
              
              
            </ul>
            
            <li><a class="nav-link" href="../profil.php">Profil</a></li>
            
          </li>
          <li><a class="nav-link scrollto" href="../index.php#contact">Kontakt</a></li>
          <?php if($isLoggedIn): ?>
            <li><a class="getstartedout scrollto" href="../forms/logout.php">Logout</a></li>
          <?php else: ?>
            <li><a class="getstarted scrollto" href="../forms/Login.php">Login</a></li>
        <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center" style="color: white;font-style:italic">
          <h2>Točionica</h2>
          <ol>
            <li><a href="../index.php">Party M</a></li>
            <li><a href="../restoranikafici.php">Restorani/Kafići</a></li>
            <li>Točionica</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

 <main id="main">

    

<div class="row">
            <div class="col-lg-4 offset-lg-2 col-md-6 offset-md-1 col-sm-8 offset-sm-2 col-10 offset-1 info">
              
                <br>
              <h1>Točionica Liman</h1>
                <button class="button1">Jelovnik</button>
                <a href="./kartapica.pdf" target="_blank"><button class="button1">Karta Pića</button></a>
                <button class="button1 gotogalerija">Galerija</button>
              <br>
              <br>
                <p>Jela: Burgeri i Specijaliteti <br>Pića: Domaći Sokovi, Kraft Piva.. </p>
                <p style="font-weight:bolder">Signature Dishes & Cocktails</p>
                
                <small>Radno Vreme: <br> Ponedeljak: 08:00-23:00 <br> Utorak: 08:00-23:00 <br> Sreda: 08:00-23:00 <br> Četvrtak: 08:00-23:00 <br> Petak: 08:00-00:00 <br> Subota: 08:00-00:00 <br> Nedelja: 09:00-23:00 <br></small>
              <br>
                

                <div class="adresa">
                  
              <p><i class="bi bi-telephone"></i> Kontakt: 021/3039-226</p>
              <p><i class="bi bi-geo-alt"></i> Adresa: Narodnog Fronta 2, Novi Sad</p>

                  </div>

            </div>



            
            <div class="col-lg-4 col-md-4 col-sm-12 forma">
              <form action="./process-reservation_tocionica.php" class="formainput" method="post">
								
								<div class="form-group">
									<span class="form-label"><label for="ime" style="font-weight:bold">Rezervacija na Ime:</label></span>
									<input class="form-control" type="text" id="ime" name="ime" placeholder="<?php if (!$isLoggedIn) echo 'Niste ulogovani..';else echo'Unesite Ime rezervacije' ?>" required>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
                    <span class="form-label"><label for="vremedolaska" style="font-weight:bold">Vreme Dolaska:</label></span>
                    <input class="form-control" type="time" id="vremedolaska" name="vremedolaska" required min="08:00" max="23:59">
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<span class="form-label"><label for="zadatum" style="font-weight:bold">Datum:</label></span>
											<input class="form-control" id="zadatum" name="zadatum" type="date" required min="<?php echo date('Y-m-d'); ?>" 
                                                                                                   max="<?php echo date('Y-m-d', strtotime('+6 days')); ?>" 
                                                                                                   value="<?php echo date('Y-m-d'); ?>">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="form-group">
											<span class="form-label"><label for="brojljudi" style="font-weight:bold">Broj Ljudi:</label></span>
											<select id="brojljudi" name="brojljudi" class="form-control">
												<option></option>
												<option>1</option>
												<option>2</option>
												<option>3</option>
												<option>4</option>
												<option>5</option>
												<option>6</option>
											</select>
											<span class="select-arrow"></span>
										</div>
									</div>
									<div class="col-sm-6 offset-lg-2">
										<div class="form-group">
											<label for="vrstarez">Odaberite opciju:</label>
												<div class="form-check">
													<input class="form-check-input" type="radio" name="vrstarez" id="option1" value="Piće" checked>
													<label class="form-check-label" for="option1">
														Piće
													</label>
													</div>
												<div class="form-check">
													<input class="form-check-input" type="radio" name="vrstarez" id="option2" value="Piće i Hrana">
													<label class="form-check-label" for="option2">
														Piće i Hrana
													</label>
												</div>
										</div>
									</div>
									
								</div>

								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<span class="form-label"><label for="mestosedenja" style="font-weight:bold">Mesto Sedenja:</label></span>
											<select id="mestosedenja" name="mestosedenja" class="form-control">
												<option selected>Unutra</option>
												<option>Bašta</option>
												
											</select>
											<span class="select-arrow"></span>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label for="sedenje">Sedenje:</label>
												<div class="form-check">
													<input class="form-check-input" type="radio" name="sedenje" id="option1" value="nisko" checked>
													<label class="form-check-label" for="option1">
														Nisko
													</label>
													</div>
												<div class="form-check">
													<input class="form-check-input" type="radio" name="sedenje" id="option2" value="visoko">
													<label class="form-check-label" for="option2">
														Visoko
													</label>
												</div>
										</div>
									</div>
									
									
								</div>
								<div class="form-group">
									<span class="form-label"><label for="brojtelefona" style="font-weight:bold">Broj Telefona:</label></span>
									<input class="form-control" type="text" id="brojtelefona" name="brojtelefona" placeholder="Unesite vas broj telefona..." required>
								</div>


                <input type="hidden" name="user_email" value="<?php echo htmlspecialchars($user_email);?>">
                <br>
                
								<div class="form-btn">
                <?php if (!$isLoggedIn): ?>
                  <small class="message" style="font-weight:bold">Za rezervaciju morate biti ulogovani !</small>
                <?php endif; ?>
									<button class="submit-btn" <?php if (!$isLoggedIn) echo 'disabled'; ?>>Pošalji Rezervaciju</button>
								</div>
							</form>
<br>
<br>
                


  </div>

</div>
<br>
<br>

<div class="row">
              <div class="col-lg-4 offset-lg-2 col-10 offset-1">
                <div class="viseinfo">
                  <h2>Više Informacija:</h2>
                  <h3>Ocena:</h3>
                  <p><a href="https://www.google.com/search?q=tocionica&rlz=1C1ONGR_enRS1073RS1073&oq=&gs_lcrp=EgZjaHJvbWUqCQgAECMYJxjqAjIJCAAQIxgnGOoCMgkIARAjGCcY6gIyCQgCECMYJxjqAjIJCAMQIxgnGOoCMgkIBBAjGCcY6gIyCQgFECMYJxjqAjIJCAYQIxgnGOoCMgkIBxAjGCcY6gLSAQg2MjFqMGoxNagCCLACAQ&sourceid=chrome&ie=UTF-8#lrd=0x475b11566afa63c9:0x2febff958a5f3694,1,,,,"><img src="../assets/img/tocionica/zvezde.svg" alt="" style="width:130px"><small style="font-style: italic"> - Google Reviews</small></a></p>
                  <h3>Specijali:</h3>
                  <p style="font-style: italic">"Točionica redovno osvežava jelovnik nedeljnim specijalitetima."</p>
                  <h3>Prosečna cena za dvoje:</h3>
                  <p>~2000 RSD.</p>
                  <h3>Mogućnost plaćanja:</h3>
                  <p>Gotovina/Kartica</p>
                  <h3>Rad kuhinje:</h3>
                  <p>Kuhinja se zatvara sat vremena pre zatvaranja lokala</p>
                  <h3>Parking:</h3>
                  <p>Besplatan parking u okolini lokala</p>
                  <h3>Oficijalni vebsajt:</h3>
                  <p><a href="https://tocionicapab.com/liman/" style="text-decoration:underline">Точионица Паб</a></p>
                </div>
              </div>

              <div class="col-lg-4">
                  <div class="dodaci">
                  <h3>Lokacija:</h3>
                      <ul>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2809.258820938909!2d19.84437227609204!3d45.24255877107125!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475b11566afa63c9%3A0x2febff958a5f3694!2sTO%C4%8CIONICA%20Liman!5e0!3m2!1sen!2srs!4v1710435887060!5m2!1sen!2srs" width="350" height="200" style="border:2px solid #4b137d;border-radius:30px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                      </ul>
                  <h3>Još:</h3>
                    <ul>
                      <p>Izvanredni kokteli <i class="bi bi-cup-straw"></i></p>
                      <p>Doručak do 13:00 <i class="bi bi-egg-fried"></i></p>
                      <p>Pet friendly <i class="material-icons" style="font-size:14px">pets</i></p>
                      <p>Dostava hrane <i class="bi bi-truck"></i></p>
                      <a href="https://wolt.com/sr/srb/novi_sad/restaurant/toionica-ns" target="_blank" style="text-decoration: underline;"><p><i class="bi bi-arrow-right-short"></i> Poruči preko Wolta</p></a>
                    </ul>
                     
                     
                    
                  </div>
              </div>

              
     
</div>
<br>


<div class="col-lg-8 offset-lg-2 col-10 offset-1 galerija">
  <h1>Galerija</h1>
  <div class="grid">
    <div class="item" style="background-image: url(../assets/img/tocionica/toc4.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc14.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc11.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc3.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc7.jpg)"></div>
  </div>
  <div class="grid">
    <div class="item" style="background-image: url(../assets/img/tocionica/toc9.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc6.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc12.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc15.jpg)"></div>
    
    <div class="item" style="background-image: url(../assets/img/tocionica/toc17.jpg)"></div>
  </div>
</div>





</main>


















<br>
<br>

<a href="http://www.freepik.com" style="font-style: italic;">Photo designed by starline / Freepik</a>


  




  <!-- ======= Footer ======= -->
  <footer id="footer" style="font-style:italic">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <h3>Party M <img src="../assets/img/logopartym.png" alt="" style="width:70px; height:70px;"></h3>
              
              <p>
                <strong>Email:</strong> info@partym.rs<br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bi bi-skype"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 offset-lg-6 col-md-6 footer-links">
            <h4>Nasi Servisi</h4>
            <ul>
              
              <li><i class="bi bi-arrow-right-short"></i> <a href="../restoranikafici.php">Restorani/Kafici</a></li>
              
              
            </ul>
            <br>
            <h4>Partneri:</h4>
            <ul>
              
              <li><i class="bi bi-arrow-right-short"></i> <a href="#">Točionica</a></li>
              
              
            </ul>
            
          </div>

          

        </div>
      </div>
    </div>
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Party M</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        Designed by Zaun
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  

  <script>
var loader = document.getElementById("preloader");

window.addEventListener("load", function(){
  loader.style.display = "none";
  
})
</script>

  <!-- Vendor JS Files -->
  <script src="../assets/"></script>
  <script src="../assets//vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets//vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets//vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets//vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets//vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets//js/main.js"></script>


  <script>
document.querySelector('.gotogalerija').addEventListener('click', function() {
  const gallerySection = document.querySelector('.galerija');
  if (gallerySection) {
    gallerySection.scrollIntoView({ behavior: 'smooth' });
  }
});
  </script>






  

</body>

</html>