<?php
// dbconfig.php
$servername = "localhost";
$username = "root";
$password = "Sinke008"; 
$database = "rezervacije"; 
